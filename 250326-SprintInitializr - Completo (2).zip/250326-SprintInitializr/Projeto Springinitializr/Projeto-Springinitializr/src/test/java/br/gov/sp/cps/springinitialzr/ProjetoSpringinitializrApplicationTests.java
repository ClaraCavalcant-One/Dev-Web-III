package br.gov.sp.cps.springinitialzr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringinitializrApplicationTests {

	@Test
	void contextLoads() {
	}

}
