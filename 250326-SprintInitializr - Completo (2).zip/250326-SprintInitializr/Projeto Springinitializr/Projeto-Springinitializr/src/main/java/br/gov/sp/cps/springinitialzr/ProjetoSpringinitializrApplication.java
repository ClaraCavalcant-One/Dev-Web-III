package br.gov.sp.cps.springinitialzr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSpringinitializrApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSpringinitializrApplication.class, args);
	}

}
