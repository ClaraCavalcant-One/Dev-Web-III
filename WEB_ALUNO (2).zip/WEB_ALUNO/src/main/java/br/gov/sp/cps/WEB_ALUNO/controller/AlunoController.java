package br.gov.sp.cps.WEB_ALUNO.controller;

import br.gov.sp.cps.WEB_ALUNO.entity.Aluno;
import br.gov.sp.cps.WEB_ALUNO.service.AlunoService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@RequiredArgsConstructor
@Controller
@RequestMapping("/teste/alunos")
public class AlunoController {
    @Autowired
    private AlunoService alunoService;

    @PostMapping
    public ResponseEntity<Aluno> cadastro(@RequestBody Aluno aluno){
        Aluno alunoSalvo = alunoService.cadastrar(aluno);
        return ResponseEntity.status(HttpStatus.CREATED).body(alunoSalvo);
    }

    @GetMapping("/{Usuario}")
    public ResponseEntity<Aluno> consultaUm(@PathVariable Long usuario){
        Aluno aluno = alunoService.consultarPorUsuario(usuario);
        return ResponseEntity.ok(aluno);
    }

    @GetMapping
    public ResponseEntity<Iterable<Aluno>> consultarTodos(){
        Iterable<Aluno> listaAlunos = alunoService.listar();
        return ResponseEntity.ok(listaAlunos);
    }

    @PatchMapping("/{Usuario}")
    public ResponseEntity<Aluno> alterarSenha(@PathVariable Long usuario, @RequestBody Aluno aluno){
        Aluno alunoAlterado = alunoService.alterarSenha(usuario, aluno.getSenha());
        return ResponseEntity.ok(alunoAlterado);
    }

    @PatchMapping("/{Usuario}")
    public ResponseEntity<Aluno> alterarEmail(@PathVariable Long usuario, @RequestBody Aluno aluno){
        Aluno alunoAlterado = alunoService.alterarEmail(usuario, aluno.getEmail());
        return ResponseEntity.ok(alunoAlterado);
    }

    @PatchMapping("/{Usuario}")
    public ResponseEntity<Aluno> alterarTelefone(@PathVariable Long usuario, @RequestBody Aluno aluno){
        Aluno alunoAlterado = alunoService.alterarSenha(usuario, aluno.getTelefone());
        return ResponseEntity.ok(alunoAlterado);
    }

    @DeleteMapping("/{Usuario}")
    public ResponseEntity<Aluno> deletar(@PathVariable Long usuario){
        alunoService.deletarPorId(usuario);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity<Void> deletarTodos(){
        alunoService.deletarTodos();
        return ResponseEntity.noContent().build();
    }







}
