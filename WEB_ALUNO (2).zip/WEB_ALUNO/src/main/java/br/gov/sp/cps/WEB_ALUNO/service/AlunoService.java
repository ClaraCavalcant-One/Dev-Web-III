package br.gov.sp.cps.WEB_ALUNO.service;

import br.gov.sp.cps.WEB_ALUNO.entity.Aluno;
import br.gov.sp.cps.WEB_ALUNO.repository.AlunoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@RequiredArgsConstructor
@Service
public class AlunoService {

    @Autowired
    private AlunoRepository alunoRepository;

    @Transactional
    public Aluno cadastrar(Aluno aluno){
        return alunoRepository.save(aluno);
    }

    @Transactional(readOnly = true)
    public Aluno consultarPorUsuario(Long usuario){
        Aluno aluno = alunoRepository.findById(usuario).orElseThrow(
                () -> new RuntimeException("Aluno não encontrado")
        );
        return aluno;
    }

    @Transactional(readOnly = true)
    public Iterable<Aluno> listar(){
        return alunoRepository.findAll();
    }

    @Transactional
    public Aluno alterarSenha(Long usuario, String senha){
        Aluno aluno = consultarPorUsuario(usuario);
        aluno.setSenha(senha);
        return aluno;
    }

    @Transactional
    public Aluno alterarEmail(Long usuario, String email){
        Aluno aluno = consultarPorUsuario(usuario);
        aluno.setEmail(email);
        return aluno;
    }

    @Transactional
    public Aluno alterarTelefone(Long usuario, String telefone){
        Aluno aluno = consultarPorUsuario(usuario);
        aluno.setTelefone(telefone);
        return aluno;
    }

    @Transactional
    public void deletarPorId(Long usuario){
        if (!alunoRepository.existsById(usuario)){
            throw new RuntimeException("Aluno não encontrado");
        }

        alunoRepository.deleteById(usuario);
    }

    @Transactional
    public void deletarTodos(){
        alunoRepository.deleteAll();
    }
}
