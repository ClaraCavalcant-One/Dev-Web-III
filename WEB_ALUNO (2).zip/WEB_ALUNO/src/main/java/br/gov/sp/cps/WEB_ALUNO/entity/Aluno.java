package br.gov.sp.cps.WEB_ALUNO.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter @Setter @NoArgsConstructor
@Entity
@Table(name = "alunos")
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Usuario")
    private Long usuario;

    @Column(name= "Senha", nullable = false, length = 200)
    private String senha;

    @Column(name = "Nome", nullable = false, length = 30)
    private String nome;

    @Column(name = "Curso", nullable = false, length = 30)
    private String curso;

    @Column(name = "email", nullable = false, unique = true, length = 30)
    private String email;

    @Column(name = "Telefone", nullable = false, length = 9, unique = true)
    private String telefone;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status", nullable = false)
    private Status status;

    @Column(name = "Disciplina", nullable = false)
    private String disciplina;

    @Column(name = "Nota1")
    private Double nota1;

    @Column(name = "Nota2")
    private Double nota2;

    @Column(name = "Media")
    private Double media;





    public enum Status {
        cursado, trancado, formado
    }


    @Override
    public int hashCode() {
        return Objects.hash(usuario);
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Aluno aluno = (Aluno) o;
        return Objects.equals(usuario, aluno.usuario);

    }

    @Override
    public String toString(){
        return "Usuário: " + this.usuario + "\nSenha: " + this.senha + "\nNome: " + this.nome + "\nE-mail: " + this.email + "\nTelefone: " + this.telefone + "\nStatus: " + this.status + "\nDisciplina: " + this.disciplina;
    }
}
