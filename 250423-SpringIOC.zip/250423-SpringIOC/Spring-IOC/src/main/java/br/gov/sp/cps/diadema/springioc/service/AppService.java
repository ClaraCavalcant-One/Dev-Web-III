package br.gov.sp.cps.diadema.springioc.service;

import br.gov.sp.cps.diadema.springioc.model.Cliente;
import br.gov.sp.cps.diadema.springioc.repository.AppRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppService {
    private AppRepository appRepository;

    @Autowired
    public AppService(AppRepository appRepository) {
        this.appRepository = appRepository;
    }

    public void salvarCliente(Cliente cliente){
        validarCliente(cliente);
        AppRepository appRepository = new AppRepository();
        appRepository.persistir(cliente); // Não ideal
    }

    public void validarCliente(Cliente cliente){
        // Aplica Validações
    }
}
