package br.gov.sp.cps.diadema.springioc.model;

public class Cliente {
    private String nome;

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }
}
