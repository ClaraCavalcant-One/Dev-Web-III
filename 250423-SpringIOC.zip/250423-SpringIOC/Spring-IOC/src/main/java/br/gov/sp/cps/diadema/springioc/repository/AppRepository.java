package br.gov.sp.cps.diadema.springioc.repository;

import br.gov.sp.cps.diadema.springioc.model.Cliente;
import org.springframework.stereotype.Repository;

@Repository
public class AppRepository {

    public void persistir(Cliente cliente){
        // Acesso a db e Salva o Cliente
    }
}
