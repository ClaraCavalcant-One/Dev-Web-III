package br.gov.sp.cps.diadema.springioc.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean(name="appName")
    public String appName(){
        return "Aplicação de Ioc";
    }




}
