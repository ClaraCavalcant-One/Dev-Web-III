package br.gov.sp.cps.ProjetoSpringIoC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class appProjetoIoC {

	public static void main(String[] args) {

		SpringApplication.run(appProjetoIoC.class, args);
	}

}
