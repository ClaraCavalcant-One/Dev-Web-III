package br.gov.sp.cps.ProjetoSpringIoC.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    // Inserir configuração futura;

}
