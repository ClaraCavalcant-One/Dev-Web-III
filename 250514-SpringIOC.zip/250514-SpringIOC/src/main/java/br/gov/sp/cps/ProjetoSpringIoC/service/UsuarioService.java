package br.gov.sp.cps.ProjetoSpringIoC.service;

import br.gov.sp.cps.ProjetoSpringIoC.entity.Usuario;
import br.gov.sp.cps.ProjetoSpringIoC.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;


    public Usuario salvar(Usuario usuario){
        return usuarioRepository.save(usuario);
    }


    public Usuario buscarPorId(Long id){
        return usuarioRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Usuario não encontrado...")
        );
    }

    public List<Usuario> listarTodos(){
        return usuarioRepository.findAll();
    }


    public Usuario editarSenha(Long id, String novaSenha){
        Usuario usuario = buscarPorId(id);
        usuario.setPassword(novaSenha);
        return usuarioRepository.save(usuario);
    }


    public void deletarPorId(Long id){
        usuarioRepository.deleteById(id);
    }


    public void deletarTodos(){
        usuarioRepository.deleteAll();
    }
}
