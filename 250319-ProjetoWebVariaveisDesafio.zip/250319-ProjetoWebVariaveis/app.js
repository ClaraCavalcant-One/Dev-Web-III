// Importação dos Modulos:
const http = require('http');  // Modulo usado para uso do protocolo http
const url = require('url');    // Modulo para tratar URL (caminho) 


// Configuração do Projeto (temporario):
const PORT = 4800;

// Criação do Servidor:
const server = http.createServer((req, res) => {
    // Utilizando o Modulo URL (Criando os end points):
    const reqUrl = url.parse(req.url, true);
    const path = reqUrl.pathname;
    const query = reqUrl.query;
    // Comparação e criação dos end-points:
    if (path === '/'){
        res.writeHead(200, {'content-type': "text/plain; charset=utf-8"});
        res.end("Pagina Principal do Projeto");

    } else if (path === '/imc') {
        // Receber as variaveis digitadas na URL:
        var valorPeso = parseFloat(query.peso);
        var valorAltura = parseFloat(query.altura);

        // Processsar as informações:
        if (isNaN(valorAltura) || isNaN(valorPeso)){
            res.writeHead(400, {'content-type': 'text/plain; charset=utf-8'});
            res.end("400 - Entrada Invalida - Entre com valores validos.");
        } else {
            // Calculo do IMC:
            var valorIMC = valorPeso / (valorAltura * valorAltura);
            var classificacao;
            // Classificação do IMC:
            if (valorIMC < 18.5){
                classificacao = "Baixo Peso";
            }
            else if (valorIMC >= 18.5 && valorIMC <= 24.9){
                classificacao = "Peso adequado";
            }

            else if (valorIMC >= 25 && valorIMC <= 29.9){
                classificacao = "Sobrepeso";
            }
            
            else if (valorIMC >= 30 && valorIMC <= 34.9){
                classificacao = "Obesidade grau I";
            }

            else if (valorIMC >= 35 && valorIMC <= 39.9){
                classificacao = "Obesidade grau II";
            }

            else if (valorIMC >= 40){
                classificacao = "Obesidade grau III";
            }

            else {
                classificacao = "Inválida";
            }

            // Mostrar os resultados:
            res.writeHead(200, {'content-type': 'text/plain; charset=utf-8'})
            res.end(`IMC: ${valorIMC.toFixed(2)} - Peso: ${valorPeso.toFixed(2)} e Altura: ${valorAltura.toFixed(2)}\nClassificação: ${classificacao}`);
            
        }



    }

    else if (path === '/notas'){
        var notap1 = parseFloat(query.p1);
        var notap2 = parseFloat(query.p2);
        if (isNaN(notap1) || isNaN(notap2)){
            res.writeHead(400, {'content-type': 'text/plain; charset=utf-8'});
            res.end("Insira Notas ou Insira Notas Válidas");
        }
        var media = (notap1 + notap2) / 2;
        var status;
        if (media >= 6){
            status = "Aprovado";
        }
        else {
            status = "Reprovado";
        }

        res.writeHead(200, {'content-type': 'text/plain; charset=utf-8'});
        res.end(`Média: ${media.toFixed(2)} - P1: ${notap1.toFixed(2)} e P2: ${notap2.toFixed(2)}\nStatus: ${status}`);
    }

    else if (path === '/dolar'){
        var reais = parseFloat(query.r);
        var dolar = parseFloat(query.d);

        if (isNaN(reais) || isNaN(dolar)){
            res.writeHead(400, {'content-type': 'text/plain; charset=utf-8'});
            res.end("Insira valores ou Insira valores válidos");
        }
        
        var qtdDolar = reais / 5.76;
        if (qtdDolar > dolar){
            qtdDolar = dolar;
        }
       

        res.writeHead(200, {'content-type': 'text/plain; charset=utf-8'});
        res.end(`Dólares: ${dolar.toFixed(2)} Reais: ${reais.toFixed(2)}\nQuantidade de dólares que podem ser comprados ${qtdDolar.toFixed(2)}`);
        
    }
    else {
        res.writeHead(404, {'content-type': "text/plain; charset=utf-8"});
        res.end("Pagina Não Encontrada")
    }

})
// Configuração do Servidor:
server.listen(PORT, () => {
    console.log(`[CONECTADO] - Servidor iniciado em porta: ${PORT}`);
})